(function(){
  const measurementId=''; // Add the GA4 Measurement ID after Google account setup.
  const privacySignal=navigator.globalPrivacyControl===true||navigator.doNotTrack==='1';
  window.tgTrack=function(name,params={}){
    if(privacySignal||typeof window.gtag!=='function')return;
    window.gtag('event',name,{...params,send_to:measurementId});
  };
  if(!measurementId||privacySignal)return;
  window.dataLayer=window.dataLayer||[];
  window.gtag=function(){window.dataLayer.push(arguments)};
  window.gtag('consent','default',{analytics_storage:'granted',ad_storage:'denied',ad_user_data:'denied',ad_personalization:'denied'});
  window.gtag('js',new Date());
  window.gtag('config',measurementId,{anonymize_ip:true,allow_google_signals:false});
  const s=document.createElement('script');s.async=true;s.src='https://www.googletagmanager.com/gtag/js?id='+encodeURIComponent(measurementId);document.head.appendChild(s);
})();
