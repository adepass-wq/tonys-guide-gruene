const catalog=[
["Live water desk","now.html","Tool","Canyon Lake level elevation conservation pool Canyon Dam release Sattler Guadalupe Comal flow cfs gage weather wind rain safety conditions"],
["Exhaustive events","events.html","Tool","events today tonight weekend music concert festival family market arts community sports Gruene New Braunfels Canyon Lake"],
["Interactive trip tools","tools.html","Tool","planner choose base checklist saved trip practical"],
["The Calaboose: San Marcos Black History","culture/calaboose-san-marcos.html","History","Calaboose museum San Marcos Dunbar Black African American Eddie Durham Cephas USO"],
["Canyon Lake Country","guides/canyon-lake-country.html","Guide","Canyon Lake geography Sattler Startzville Fischer Spring Branch north south west shores communities"],
["Canyon Lake Gorge","culture/canyon-lake-gorge.html","History","Canyon Lake Gorge geology flood 2002 limestone fossils spillway"],
["Field map","field-map.html","Tool","map geography driving access nearby route"],
["74 Places That Explain the Region","guides/destinations.html","Guide","destinations attractions places museums parks music food historic sites map"],
["Canyon Lake, Shore by Shore","guides/canyon-lake-by-shore.html","Guide","Canyon Lake north south west shore parks ramps Comal Canyon Potters Creek Cranes Mill"],
["River Road, Read Slowly","guides/river-road.html","Guide","River Road scenic drive crossings access camps traffic Sattler Guadalupe"],
["Flood Country","guides/floods-and-high-water.html","Guide","flood high water safety 1972 1998 2002 Canyon Dam mitigation warning sirens"],
["Texas German Is Still Here","culture/texas-german-language.html","History","Texas German dialect language speakers endangered archive New Braunfels UT Austin"],
["The Names Under Your Feet","culture/streets-and-places.html","History","streets names Main Plaza San Antonio Seguin Castell Katy Grape Faust bridge"],
["Start here","guides/first-visit.html","Guide","first visit orientation weekend plan Gruene New Braunfels Canyon Lake Guadalupe"],
["Gruene: Beyond the Postcard","guides/gruene.html","Guide","Gruene historic district music cotton shops walk river evening"],
["New Braunfels: Two Rivers, Many Histories","guides/new-braunfels.html","Guide","New Braunfels Comal Guadalupe culture German Tejano Black history"],
["Canyon Lake: Choose the Right Shore","guides/canyon-lake.html","Guide","Canyon Lake shore access parks ramps swimming boating quiet"],
["The Guadalupe: Read the River Before You Go","guides/guadalupe-river.html","Guide","Guadalupe tubing paddling flow access safety quiet river"],
["Tony’s Perfect 48 Hours","guides/48-hours.html","Itinerary","weekend two day itinerary food music river lake"],
["Where to Stay","guides/where-to-stay.html","Guide","lodging hotel rental base Gruene Canyon Lake New Braunfels"],
["On the Water","guides/on-the-water.html","Guide","boating swimming paddling ramps marina water"],
["Tubing Without Regret","guides/tubing.html","Guide","Comal Guadalupe tubing shuttle parking crowds flow"],
["Families","guides/families.html","Guide","family children kids easy activities playground"],
["Accessible Trip Planning","guides/accessible.html","Guide","accessible accessibility wheelchair mobility parking surfaces"],
["Rainy Day Plan","guides/rainy-day.html","Guide","rain rainy indoor museum food backup weather"],
["Food & Local Character","guides/food.html","Guide","restaurants dining breakfast Mexican barbecue German upscale family Canyon Lake Gruene New Braunfels"],["Music Theatre & Entertainment","guides/entertainment.html","Guide","entertainment live music theatre film nightlife family Gruene Hall Whitewater Brauntex Circle Arts"],["Texas Barbecue & The Salt Lick","guides/texas-barbecue.html","Feature","BBQ barbecue brisket ribs sausage smoke Driftwood Salt Lick Lockhart Luling Seguin"],["Caves & Underground Performances","guides/caves.html","Feature","caves caverns Natural Bridge Cave Without a Name underground concert performance geology"],["Hill Country Drives Cycling & Oil Country","guides/hill-country-roads.html","Route","scenic drive cycling bicycle Wimberley Blanco Driftwood Seguin Luling oil wells pumpjacks Hill Country"],
["Before 1845","culture/before-1845.html","History","Indigenous Tonkawa Waco Lipan Apache Spanish Mexican Veramendi"],
["German Texas, Without the Fairy Tale","culture/german-texas.html","History","German immigration Adelsverein language culture settlement"],
["Cotton Built Gruene — But Who Worked It?","culture/cotton-gruene.html","History","cotton sharecropping tenant labor gin Gruene workers"],
["Black New Braunfels","culture/black-new-braunfels.html","History","Black African American Allen Chapel AME Live Oak Baptist community"],
["West End & Tejano New Braunfels","culture/west-end-tejano.html","History","Mexican American Tejano West End dance hall Delgado"],
["Before Canyon Lake","culture/before-canyon-lake.html","History","Cranes Mill Hancock dam displacement farms ranches reservoir"],
["Dance Halls, Music & Public Life","culture/music-dance-halls.html","History","Gruene Hall music dance hall public life"],
["The Whole Story Route","culture/whole-story-route.html","Route","self guided history Black Tejano German cotton cemetery"],
["About Tony","about.html","About","Tony DePass editorial standards corrections sources"],
["Editorial sources","sources.html","About","sources citations research accuracy corrections"]
];
let fullCatalog=[...catalog];
let eventIndex=[];
const norm=s=>(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
const words=q=>norm(q).split(/\s+/).filter(x=>x&&!["this","the","a","an","for","near","me"].includes(x));
const synonyms={kids:["family","children"],wheelchair:["accessible","accessibility","mobility"],concert:["music"],tonight:["today","events"],restaurant:["food","dining"],rain:["rainy","indoor"],swim:["water","swimming"],hotel:["stay","lodging"],history:["culture"],quiet:["river","slow"],acl:["austin city limits"],f1:["formula 1"],play:["theatre","theater","musical"],plays:["theatre","theater","musical"],stage:["theatre","performance"],brew:["beer","brewers"]};
function score(item,terms){const title=norm(item[0]),text=norm(item.join(" "));let n=0;for(const term of terms){const variants=[term,...(synonyms[term]||[])];let hit=0;for(const v of variants){if(title.includes(v))hit=Math.max(hit,8);else if(text.includes(v))hit=Math.max(hit,3)}if(!hit)return 0;n+=hit}return n}
function eventMatches(q){const terms=words(q),now=new Date(),weekend=new Date(now);weekend.setDate(now.getDate()+(now.getDay()===0?0:7-now.getDay()));return eventIndex.filter(e=>{const text=norm([e.title,e.venue,e.area,e.category].join(" "));if(terms.includes("weekend")&&new Date(e.start)>weekend)return false;if(terms.includes("tonight")&&new Date(e.start).toDateString()!==now.toDateString())return false;return terms.filter(t=>!["this","weekend","tonight"].includes(t)).every(t=>text.includes(t)||(synonyms[t]||[]).some(s=>text.includes(s)))}).slice(0,5)}
function runSearch(track=false){const input=document.getElementById("q"),out=document.getElementById("results");let status=document.getElementById("search-status");if(!input||!out)return;if(!status){status=document.createElement('div');status.id='search-status';status.className='search-status search-status-dark';out.before(status)}const q=input.value.trim();if(!q){out.innerHTML="";status.textContent="";return}const terms=words(q),pages=fullCatalog.map(x=>({x,s:score(x,terms)})).filter(o=>o.s).sort((a,b)=>b.s-a.s).slice(0,10),events=eventMatches(q);const rows=[...events.map(e=>`<div class="result"><div class="result-type">Event · ${new Date(e.start).toLocaleDateString([],{month:"short",day:"numeric"})}</div><a href="${e.source}" target="_blank" rel="noopener"><strong>${e.title}</strong></a><div class="note">${e.venue||e.area} · ${e.category}</div></div>`),...pages.map(({x})=>`<div class="result"><div class="result-type">${x[2]}</div><a href="/${x[1]}"><strong>${x[0]}</strong></a><div class="note">${x[4]||`Matched in Tony’s ${x[2].toLowerCase()} library`}</div></div>`)];status.textContent=rows.length?`Showing ${events.length} matching event${events.length===1?'':'s'} and ${pages.length} page${pages.length===1?'':'s'} for “${q}”.`:`No close matches for “${q}”.`;out.innerHTML=rows.length?rows.join("")+`<div class="result search-all"><a href="/events.html?search=${encodeURIComponent(q)}"><strong>Search the complete events calendar for “${q}” →</strong></a></div>`:`<div class="result"><strong>No close match.</strong><div class="note">Try a place, activity, date, accessibility need, history topic or “music this weekend.”</div><a href="/events.html">Open the complete events desk →</a></div>`;if(track)window.tgTrack?.('search',{search_term:q,result_count:rows.length,event_results:events.length,page_results:pages.length})}
async function loadFullCatalog(){try{const r=await fetch('/search-index.json',{cache:'no-store'});if(!r.ok)return;const generated=await r.json(),merged=new Map();[...catalog,...generated].forEach(x=>merged.set(x[1],x));fullCatalog=[...merged.values()];if(document.getElementById('q')?.value.trim())runSearch()}catch(e){}}
function enhanceMobileNav(){const bar=document.querySelector('header .nav'),nav=bar?.querySelector('nav');if(!bar||!nav||bar.querySelector('.nav-toggle'))return;nav.id=nav.id||'primary-nav';const b=document.createElement('button');b.className='nav-toggle';b.type='button';b.setAttribute('aria-controls',nav.id);b.setAttribute('aria-expanded','false');b.innerHTML='<span aria-hidden="true">☰</span> Menu';b.addEventListener('click',()=>{const open=nav.classList.toggle('open');b.setAttribute('aria-expanded',String(open));b.innerHTML=`<span aria-hidden="true">${open?'×':'☰'}</span> ${open?'Close':'Menu'}`});bar.insertBefore(b,nav)}
async function loadSearchEvents(){try{const r=await fetch("/events-fallback.json",{cache:"no-store"});if(r.ok)eventIndex=await r.json()}catch(e){}try{const r=await fetch("/events-destination.json",{cache:"no-store"});if(r.ok)eventIndex=[...eventIndex,...await r.json()]}catch(e){}try{const controller=new AbortController();setTimeout(()=>controller.abort(),3500);const r=await fetch("https://tonys-guide-gruene-events-live.onrender.com/events",{cache:"no-store",signal:controller.signal});if(r.ok){const live=(await r.json()).events||[];const merged=new Map();[...eventIndex,...live].forEach(e=>merged.set(`${norm(e.title)}|${(e.start||'').slice(0,10)}|${norm(e.venue)}`,e));eventIndex=[...merged.values()]}}catch(e){}}
function addDiscovery(){if(!document.querySelector('link[type="application/rss+xml"]')){const l=document.createElement('link');l.rel='alternate';l.type='application/rss+xml';l.title='Tony’s Guide updates';l.href='/feed.xml';document.head.appendChild(l)}if(!document.querySelector('script[src*="analytics.js"]')){const s=document.createElement('script');s.src='/assets/analytics.js?v=1';s.defer=true;document.head.appendChild(s)}document.querySelectorAll('footer .footgrid').forEach(f=>{if(!f.querySelector('a[href="/privacy.html"]')){const p=document.createElement('p');p.className='footer-policy';p.innerHTML='<a href="/privacy.html">Privacy</a> · <a href="/feed.xml">RSS</a>';f.lastElementChild?.appendChild(p)}})}
function addMeasurement(){document.addEventListener('click',e=>{const a=e.target.closest('a');if(!a)return;let u;try{u=new URL(a.href,location.href)}catch{return}const label=(a.textContent||'').trim().slice(0,100);if(u.hostname==='www.google.com'&&u.pathname.startsWith('/maps/'))window.tgTrack?.('map_click',{link_text:label,destination:u.searchParams.get('destination')||u.searchParams.get('query')||''});else if(u.origin!==location.origin)window.tgTrack?.('outbound_click',{link_url:u.origin+u.pathname,link_text:label});else if(u.pathname==='/events.html')window.tgTrack?.('events_entry',{link_text:label,source_page:location.pathname})})}
document.addEventListener("DOMContentLoaded",()=>{addDiscovery();addMeasurement();enhanceMobileNav();const q=document.getElementById("q");if(q){q.addEventListener("input",()=>runSearch(false));q.addEventListener("keydown",e=>{if(e.key==="Enter")runSearch(true);if(e.key==="Escape"){q.value="";runSearch(false)}});q.closest('.searchbox')?.querySelector('button')?.addEventListener('click',()=>runSearch(true));document.querySelectorAll("[data-query]").forEach(b=>b.addEventListener("click",()=>{q.value=b.dataset.query;runSearch(true);q.focus()}))}loadFullCatalog();loadSearchEvents()});

const MAP_CONTEXT={
"/guides/first-visit.html":["Gruene Historic District, New Braunfels, TX","Map the historic district"],
"/guides/gruene.html":["Gruene Historic District, New Braunfels, TX","Map Gruene"],
"/guides/new-braunfels.html":["Main Plaza, New Braunfels, TX","Map downtown New Braunfels"],
"/guides/canyon-lake.html":["Canyon Lake Dam, Texas","Map Canyon Lake"],
"/guides/guadalupe-river.html":["Guadalupe River, New Braunfels, TX","Map the Guadalupe"],
"/guides/48-hours.html":["Gruene Hall, New Braunfels, TX","Map the itinerary anchor"],
"/guides/where-to-stay.html":["Gruene Historic District, New Braunfels, TX","Compare from Gruene"],
"/guides/on-the-water.html":["Canyon Lake, Texas","Map water access"],
"/guides/tubing.html":["Prince Solms Park, New Braunfels, TX","Map the tubing district"],
"/guides/families.html":["Landa Park, New Braunfels, TX","Map the family-day anchor"],
"/guides/accessible.html":["Landa Park, New Braunfels, TX","Map an accessible starting point"],
"/guides/rainy-day.html":["Sophienburg Museum, New Braunfels, TX","Map the rainy-day anchor"],
"/guides/food.html":["Gruene Historic District, New Braunfels, TX","Map the dining area"],
"/culture/before-1845.html":["Comal Springs, New Braunfels, TX","Map Comal Springs"],
"/culture/german-texas.html":["Sophienburg Museum, New Braunfels, TX","Map the history anchor"],
"/culture/cotton-gruene.html":["Gruene Historic District, New Braunfels, TX","Map historic Gruene"],
"/culture/black-new-braunfels.html":["Allen Chapel AME Church, New Braunfels, TX","Map the community anchor"],
"/culture/west-end-tejano.html":["West End Park, New Braunfels, TX","Map West End"],
"/culture/before-canyon-lake.html":["Canyon Lake Dam, Texas","Map the transformed valley"],
"/culture/music-dance-halls.html":["Gruene Hall, New Braunfels, TX","Map Gruene Hall"],
"/culture/whole-story-route.html":["Landa Park, New Braunfels, TX","Start the route in Maps"]
};
function addContextMap(){const item=MAP_CONTEXT[location.pathname];if(!item)return;const hero=document.querySelector('.article-hero .wrap');if(!hero)return;const box=document.createElement('div');box.className='map-actions';const search='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(item[0]);const directions='https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(item[0]);box.innerHTML=`<a class="map-link light" href="${search}" target="_blank" rel="noopener">⌖ ${item[1]}</a><a class="map-link light" href="${directions}" target="_blank" rel="noopener">Get directions</a>`;hero.appendChild(box)}
document.addEventListener("DOMContentLoaded",addContextMap);
