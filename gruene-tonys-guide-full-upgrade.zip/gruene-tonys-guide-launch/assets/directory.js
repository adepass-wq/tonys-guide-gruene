function filterDirectory(){
 const cards=[...document.querySelectorAll('.directory-card')];
 const q=(document.getElementById('dir-q')?.value||'').toLowerCase().trim();
 const filters=['area','type','time','fit','ownership'].map(id=>[id,document.getElementById(id)?.value||'all']);
 let shown=0;
 cards.forEach(card=>{
  const text=(card.dataset.search||card.textContent).toLowerCase();
  const okText=!q||q.split(/\s+/).every(w=>text.includes(w));
  const okFilters=filters.every(([key,val])=>{
   if(val==='all')return true;
   if(key==='ownership'&&val==='independent')return !card.dataset.ownership||card.dataset.ownership==='independent';
   return (card.dataset[key]||'').split('|').includes(val);
  });
  card.hidden=!(okText&&okFilters);if(!card.hidden)shown++;
 });
 const out=document.getElementById('directory-count');if(out)out.textContent=`${shown} of ${cards.length} places`;
}
document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('.directory-tools input,.directory-tools select').forEach(el=>el.addEventListener(el.tagName==='INPUT'?'input':'change',filterDirectory));
 filterDirectory();
});
