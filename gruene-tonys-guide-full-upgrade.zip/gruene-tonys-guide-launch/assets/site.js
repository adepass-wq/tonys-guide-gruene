
const guides = [
["Interactive Trip Tools","tools.html","trip planner choose base saved checklist live conditions events map"],
["Canyon Lake & Guadalupe Now","now.html","live weather lake elevation trend Guadalupe flow gage height wind rain"],
["Live Events","events.html","events music festivals family markets Canyon Lake Gruene New Braunfels"],
["Start Here: Gruene & Canyon Lake Country","guides/first-visit.html","first visit orientation Gruene New Braunfels Canyon Lake Guadalupe"],
["Gruene: Beyond the Postcard","guides/gruene.html","Gruene history music cotton food shops Guadalupe"],
["New Braunfels: Two Rivers, Many Histories","guides/new-braunfels.html","New Braunfels Comal Guadalupe culture history German Tejano Black"],
["Canyon Lake: Choose the Right Shore","guides/canyon-lake.html","Canyon Lake access parks ramps swimming boating"],
["The Guadalupe: Read the River Before You Go","guides/guadalupe-river.html","Guadalupe River tubing paddling flow access safety"],
["Before 1845","culture/before-1845.html","Indigenous Tonkawa Waco Lipan Apache Spanish Mexican Veramendi"],
["German Texas, Without the Fairy Tale","culture/german-texas.html","Adelsverein German immigration language clubs culture"],
["Cotton Built Gruene — But Who Worked It?","culture/cotton-gruene.html","cotton sharecropping tenant labor gin Gruene"],
["Black New Braunfels","culture/black-new-braunfels.html","African American Allen Chapel AME Live Oak Baptist community"],
["West End, Tejano New Braunfels","culture/west-end-tejano.html","Mexican American Tejano West End dance hall Delgado"],
["Before Canyon Lake","culture/before-canyon-lake.html","Cranes Mill Hancock dam displacement farms ranches"],
["Dance Halls, Music & Public Life","culture/music-dance-halls.html","Gruene Hall music dance hall community"],
["Tony’s Perfect 48 Hours","guides/48-hours.html","weekend itinerary food music river lake"],
["Where to Stay","guides/where-to-stay.html","lodging areas Gruene Canyon Lake New Braunfels"],
["On the Water","guides/on-the-water.html","boating swimming paddling access"],
["Tubing Without Regret","guides/tubing.html","Comal Guadalupe tubing parking crowd water"],
["Families","guides/families.html","family children activities"],
["Accessible Trip Planning","guides/accessible.html","accessibility mobility planning"],
["Rainy Day Plan","guides/rainy-day.html","rain weather indoor museums food"],
["Food & Local Character","guides/food.html","restaurants food local culture"],
["The Whole Story Route","culture/whole-story-route.html","self guided culture Black history Tejano German cotton cemetery"],
["About Tony","about.html","Tony DePass home owner Gruene background"]
];
function runSearch(){
 const q=(document.getElementById("q")?.value||"").trim().toLowerCase();
 const out=document.getElementById("results"); if(!out) return;
 if(!q){out.innerHTML="";return}
 const m=guides.filter(g=>(g.join(" ").toLowerCase()).includes(q)).slice(0,12);
 out.innerHTML=m.length?m.map(g=>`<div class="result"><a href="/${g[1]}"><strong>${g[0]}</strong></a><div class="note">${g[2]}</div></div>`).join(""):`<div class="result">No exact match. Try “history,” “river,” “Canyon Lake,” “Black history,” “German,” or “tubing.”</div>`;
}
document.addEventListener("DOMContentLoaded",()=>{
 const q=document.getElementById("q"); if(q) q.addEventListener("input",runSearch);
});
