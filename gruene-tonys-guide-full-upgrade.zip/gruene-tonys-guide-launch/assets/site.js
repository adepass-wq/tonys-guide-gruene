const catalog=[
["Live conditions","now.html","Tool","weather water lake elevation Guadalupe flow gage wind rain safety conditions"],
["Exhaustive events","events.html","Tool","events today tonight weekend music concert festival family market arts community sports Gruene New Braunfels Canyon Lake"],
["Interactive trip tools","tools.html","Tool","planner choose base checklist saved trip practical"],
["Field map","field-map.html","Tool","map geography driving access nearby route"],
["Start here","guides/first-visit.html","Guide","first visit orientation weekend plan Gruene New Braunfels Canyon Lake Guadalupe"],
["Gruene: Beyond the Postcard","guides/gruene.html","Guide","Gruene historic district music cotton shops walk river evening"],
["New Braunfels: Two Rivers, Many Histories","guides/new-braunfels.html","Guide","New Braunfels Comal Guadalupe culture German Tejano Black history"],
["Canyon Lake: Choose the Right Shore","guides/canyon-lake.html","Guide","Canyon Lake shore access parks ramps swimming boating quiet"],
["The Guadalupe: Read the River Before You Go","guides/guadalupe-river.html","Guide","Guadalupe tubing paddling flow access safety quiet river"],
["Tony’s Perfect 48 Hours","guides/48-hours.html","Itinerary","weekend two day itinerary food music river lake"],
["Where to Stay","guides/where-to-stay.html","Guide","lodging hotel rental base Gruene Canyon Lake New Braunfels"],
["On the Water","guides/on-the-water.html","Guide","boating swimming paddling ramps marina water"],
["Tubing Without Regret","guides/tubing.html","Guide","Comal Guadalupe tubing shuttle parking crowds flow"],
["Families","guides/families.html","Guide","family children kids easy activities playground"],
["Accessible Trip Planning","guides/accessible.html","Guide","accessible accessibility wheelchair mobility parking surfaces"],
["Rainy Day Plan","guides/rainy-day.html","Guide","rain rainy indoor museum food backup weather"],
["Food & Local Character","guides/food.html","Guide","restaurants dining German food Gristmill Krause Huisache"],
["Before 1845","culture/before-1845.html","History","Indigenous Tonkawa Waco Lipan Apache Spanish Mexican Veramendi"],
["German Texas, Without the Fairy Tale","culture/german-texas.html","History","German immigration Adelsverein language culture settlement"],
["Cotton Built Gruene — But Who Worked It?","culture/cotton-gruene.html","History","cotton sharecropping tenant labor gin Gruene workers"],
["Black New Braunfels","culture/black-new-braunfels.html","History","Black African American Allen Chapel AME Live Oak Baptist community"],
["West End & Tejano New Braunfels","culture/west-end-tejano.html","History","Mexican American Tejano West End dance hall Delgado"],
["Before Canyon Lake","culture/before-canyon-lake.html","History","Cranes Mill Hancock dam displacement farms ranches reservoir"],
["Dance Halls, Music & Public Life","culture/music-dance-halls.html","History","Gruene Hall music dance hall public life"],
["The Whole Story Route","culture/whole-story-route.html","Route","self guided history Black Tejano German cotton cemetery"],
["About Tony","about.html","About","Tony DePass editorial standards corrections sources"],
["Editorial sources","sources.html","About","sources citations research accuracy corrections"]
];
let eventIndex=[];
const norm=s=>(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
const words=q=>norm(q).split(/\s+/).filter(x=>x&&!["this","the","a","an","for","near","me"].includes(x));
const synonyms={kids:["family","children"],wheelchair:["accessible","accessibility","mobility"],concert:["music"],tonight:["today","events"],restaurant:["food","dining"],rain:["rainy","indoor"],swim:["water","swimming"],hotel:["stay","lodging"],history:["culture"],quiet:["river","slow"],acl:["austin city limits"],f1:["formula 1"],play:["theatre","theater","musical"],plays:["theatre","theater","musical"],stage:["theatre","performance"],brew:["beer","brewers"]};
function score(item,terms){const title=norm(item[0]),text=norm(item.join(" "));let n=0;for(const term of terms){const variants=[term,...(synonyms[term]||[])];let hit=0;for(const v of variants){if(title.includes(v))hit=Math.max(hit,8);else if(text.includes(v))hit=Math.max(hit,3)}if(!hit)return 0;n+=hit}return n}
function eventMatches(q){const terms=words(q),now=new Date(),weekend=new Date(now);weekend.setDate(now.getDate()+(now.getDay()===0?0:7-now.getDay()));return eventIndex.filter(e=>{const text=norm([e.title,e.venue,e.area,e.category].join(" "));if(terms.includes("weekend")&&new Date(e.start)>weekend)return false;if(terms.includes("tonight")&&new Date(e.start).toDateString()!==now.toDateString())return false;return terms.filter(t=>!["this","weekend","tonight"].includes(t)).every(t=>text.includes(t)||(synonyms[t]||[]).some(s=>text.includes(s)))}).slice(0,5)}
function runSearch(){const input=document.getElementById("q"),out=document.getElementById("results");if(!input||!out)return;const q=input.value.trim();if(!q){out.innerHTML="";return}const terms=words(q),pages=catalog.map(x=>({x,s:score(x,terms)})).filter(o=>o.s).sort((a,b)=>b.s-a.s).slice(0,7),events=eventMatches(q);const rows=[...events.map(e=>`<div class="result"><div class="result-type">Event · ${new Date(e.start).toLocaleDateString([],{month:"short",day:"numeric"})}</div><a href="${e.source}" target="_blank" rel="noopener"><strong>${e.title}</strong></a><div class="note">${e.venue||e.area} · ${e.category}</div></div>`),...pages.map(({x})=>`<div class="result"><div class="result-type">${x[2]}</div><a href="/${x[1]}"><strong>${x[0]}</strong></a><div class="note">${x[3]}</div></div>`)];out.innerHTML=rows.length?rows.join(""):`<div class="result"><strong>No close match.</strong><div class="note">Try a place, activity, date, accessibility need, history topic or “music this weekend.”</div><a href="/events.html">Search all events →</a></div>`}
async function loadSearchEvents(){try{const r=await fetch("/events-fallback.json",{cache:"no-store"});if(r.ok)eventIndex=await r.json()}catch(e){}try{const r=await fetch("/events-destination.json",{cache:"no-store"});if(r.ok)eventIndex=[...eventIndex,...await r.json()]}catch(e){}try{const controller=new AbortController();setTimeout(()=>controller.abort(),3500);const r=await fetch("https://tonys-guide-gruene-events-live.onrender.com/events",{cache:"no-store",signal:controller.signal});if(r.ok){const live=(await r.json()).events||[];const merged=new Map();[...eventIndex,...live].forEach(e=>merged.set(`${norm(e.title)}|${(e.start||'').slice(0,10)}|${norm(e.venue)}`,e));eventIndex=[...merged.values()]}}catch(e){}}
document.addEventListener("DOMContentLoaded",()=>{const q=document.getElementById("q");if(q){q.addEventListener("input",runSearch);q.addEventListener("keydown",e=>{if(e.key==="Escape"){q.value="";runSearch()}});document.querySelectorAll("[data-query]").forEach(b=>b.addEventListener("click",()=>{q.value=b.dataset.query;runSearch();q.focus()}))}loadSearchEvents()});

const MAP_CONTEXT={
"/guides/first-visit.html":["Gruene Historic District, New Braunfels, TX","Map the historic district"],
"/guides/gruene.html":["Gruene Historic District, New Braunfels, TX","Map Gruene"],
"/guides/new-braunfels.html":["Main Plaza, New Braunfels, TX","Map downtown New Braunfels"],
"/guides/canyon-lake.html":["Canyon Lake Dam, Texas","Map Canyon Lake"],
"/guides/guadalupe-river.html":["Guadalupe River, New Braunfels, TX","Map the Guadalupe"],
"/guides/48-hours.html":["Gruene Hall, New Braunfels, TX","Map the itinerary anchor"],
"/guides/where-to-stay.html":["Gruene Historic District, New Braunfels, TX","Compare from Gruene"],
"/guides/on-the-water.html":["Canyon Lake, Texas","Map water access"],
"/guides/tubing.html":["Prince Solms Park, New Braunfels, TX","Map the tubing district"],
"/guides/families.html":["Landa Park, New Braunfels, TX","Map the family-day anchor"],
"/guides/accessible.html":["Landa Park, New Braunfels, TX","Map an accessible starting point"],
"/guides/rainy-day.html":["Sophienburg Museum, New Braunfels, TX","Map the rainy-day anchor"],
"/guides/food.html":["Gruene Historic District, New Braunfels, TX","Map the dining area"],
"/culture/before-1845.html":["Comal Springs, New Braunfels, TX","Map Comal Springs"],
"/culture/german-texas.html":["Sophienburg Museum, New Braunfels, TX","Map the history anchor"],
"/culture/cotton-gruene.html":["Gruene Historic District, New Braunfels, TX","Map historic Gruene"],
"/culture/black-new-braunfels.html":["Allen Chapel AME Church, New Braunfels, TX","Map the community anchor"],
"/culture/west-end-tejano.html":["West End Park, New Braunfels, TX","Map West End"],
"/culture/before-canyon-lake.html":["Canyon Lake Dam, Texas","Map the transformed valley"],
"/culture/music-dance-halls.html":["Gruene Hall, New Braunfels, TX","Map Gruene Hall"],
"/culture/whole-story-route.html":["Landa Park, New Braunfels, TX","Start the route in Maps"]
};
function addContextMap(){const item=MAP_CONTEXT[location.pathname];if(!item)return;const hero=document.querySelector('.article-hero .wrap');if(!hero)return;const box=document.createElement('div');box.className='map-actions';const search='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(item[0]);const directions='https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(item[0]);box.innerHTML=`<a class="map-link light" href="${search}" target="_blank" rel="noopener">⌖ ${item[1]}</a><a class="map-link light" href="${directions}" target="_blank" rel="noopener">Get directions</a>`;hero.appendChild(box)}
document.addEventListener("DOMContentLoaded",addContextMap);
