
const CANYON_API='https://waterservices.usgs.gov/nwis/iv/?format=json&sites=08167700&period=P2D&parameterCd=62614,00035,00036,00045&siteStatus=all';
const GUAD_API='https://waterservices.usgs.gov/nwis/iv/?format=json&sites=08168500&period=P2D&parameterCd=00060,00065&siteStatus=all';
const WX_API='https://api.open-meteo.com/v1/forecast?latitude=29.86&longitude=-98.26&current=temperature_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_gusts_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=America%2FChicago&forecast_days=7';

function latest(series){
  const vals=series?.values?.[0]?.value||[];
  return vals.length?vals[vals.length-1]:null;
}
function first(series){
  const vals=series?.values?.[0]?.value||[];
  return vals.length?vals[0]:null;
}
function n(v){const x=parseFloat(v);return Number.isFinite(x)?x:null}
function findParam(data, code){
  return (data?.value?.timeSeries||[]).find(s=>(s.variable?.variableCode||[]).some(c=>c.value===code));
}
function fmt(v,d=1){return v==null?'—':Number(v).toFixed(d)}
function weatherText(code){
 const m={0:'Clear',1:'Mostly clear',2:'Partly cloudy',3:'Cloudy',45:'Fog',48:'Fog',51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',71:'Light snow',80:'Showers',81:'Showers',82:'Heavy showers',95:'Thunderstorms',96:'Thunderstorms',99:'Severe thunderstorms'};
 return m[code]||'Current conditions';
}
function trendText(delta){
 if(delta==null)return 'Trend unavailable';
 if(Math.abs(delta)<0.03)return 'essentially steady';
 return delta>0?`up ${Math.abs(delta).toFixed(2)} ft over the period`:`down ${Math.abs(delta).toFixed(2)} ft over the period`;
}
function tonysRead({temp,gust,precipProb,lakeDelta,flow}){
 let lines=[];
 if(gust!=null && gust>=25) lines.push('Wind deserves attention on open water today.');
 else if(gust!=null && gust<18) lines.push('Wind is relatively manageable for a lake day, subject to local conditions.');
 if(precipProb!=null && precipProb>=50) lines.push('Build flexibility into the day; rain or storms may interrupt water plans.');
 if(lakeDelta!=null && Math.abs(lakeDelta)>=0.15) lines.push(`Canyon Lake is ${lakeDelta>0?'rising':'falling'} enough to notice in the recent trend.`);
 if(flow!=null){
   if(flow<100) lines.push('The Guadalupe is running low at New Braunfels; expect slower water and verify outfitter conditions before tubing.');
   else if(flow<300) lines.push('The Guadalupe is on the lower side; tubing and paddling conditions can be slower than visitors expect.');
   else if(flow<1000) lines.push('Guadalupe flow is moderate; check the exact reach and access point before committing to a float.');
   else lines.push('Guadalupe flow is elevated; treat river access and outfitter guidance seriously.');
 }
 if(!lines.length) lines.push('Conditions look ordinary, but check the linked primary sources before a water-dependent outing.');
 return lines.join(' ');
}
async function loadNow(){
 let lake=null, guad=null, wx=null;
 try{
   const [a,b,c]=await Promise.all([fetch(CANYON_API),fetch(GUAD_API),fetch(WX_API)]);
   if(a.ok) lake=await a.json(); if(b.ok) guad=await b.json(); if(c.ok) wx=await c.json();
 }catch(e){}
 const elev=findParam(lake,'62614'), wind=findParam(lake,'00035'), wdir=findParam(lake,'00036'), rain=findParam(lake,'00045');
 const discharge=findParam(guad,'00060'), stage=findParam(guad,'00065');
 const el=latest(elev), elf=first(elev), fl=latest(discharge), st=latest(stage), ws=latest(wind), wd=latest(wdir), pr=latest(rain);
 const elevVal=n(el?.value), delta=(elevVal!=null&&n(elf?.value)!=null)?elevVal-n(elf.value):null;
 const flow=n(fl?.value), stageVal=n(st?.value), windVal=n(ws?.value), dirVal=n(wd?.value), precip=n(pr?.value);
 const cur=wx?.current||{}, daily=wx?.daily||{};
 const precipProb=daily?.precipitation_probability_max?.[0]??null;
 const read=tonysRead({temp:cur.temperature_2m,gust:cur.wind_gusts_10m,precipProb,lakeDelta:delta,flow});

 const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v}
 set('wx-temp',cur.temperature_2m!=null?`${Math.round(cur.temperature_2m)}°F`:'—');
 set('wx-desc',cur.weather_code!=null?weatherText(cur.weather_code):'Weather unavailable');
 set('wx-wind',cur.wind_speed_10m!=null?`${Math.round(cur.wind_speed_10m)} mph wind · gusts ${Math.round(cur.wind_gusts_10m||0)} mph`:'');
 set('lake-elev',elevVal!=null?`${fmt(elevVal,2)} ft`:'—');
 set('lake-trend',trendText(delta));
 set('lake-wind',windVal!=null?`${fmt(windVal,1)} mph${dirVal!=null?` · ${Math.round(dirVal)}°`:''}`:'—');
 set('lake-rain',precip!=null?`${fmt(precip,2)} in`:'—');
 set('guad-flow',flow!=null?`${Math.round(flow)} cfs`:'—');
 set('guad-stage',stageVal!=null?`${fmt(stageVal,2)} ft`:'—');
 set('tonys-read',read);
 set('updated',`Live data refreshed ${new Date().toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}`);
 const forecast=document.getElementById('forecast');
 if(forecast && daily.time){
   forecast.innerHTML=daily.time.map((day,i)=>`<div class="forecast-card"><strong>${new Intl.DateTimeFormat('en-US',{weekday:'short'}).format(new Date(day+'T12:00:00'))}</strong><div>${Math.round(daily.temperature_2m_max[i])}° / ${Math.round(daily.temperature_2m_min[i])}°</div><div class="note">${daily.precipitation_probability_max[i]??0}% rain</div></div>`).join('');
 }
}
document.addEventListener('DOMContentLoaded',loadNow);
