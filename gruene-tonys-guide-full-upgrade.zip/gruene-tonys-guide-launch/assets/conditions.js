const LAKE_API='https://waterservices.usgs.gov/nwis/iv/?format=json&sites=08167700&period=P2D&parameterCd=62614,00035,00036,00045&siteStatus=all';
const SATTLER_API='https://waterservices.usgs.gov/nwis/iv/?format=json&sites=08167800&period=P2D&parameterCd=00060,00065&siteStatus=all';
const NEW_BRAUNFELS_API='https://waterservices.usgs.gov/nwis/iv/?format=json&sites=08168500&period=P2D&parameterCd=00060,00065&siteStatus=all';
const COMAL_API='https://waterservices.usgs.gov/nwis/iv/?format=json&sites=08169000&period=P2D&parameterCd=00060,00065&siteStatus=all';
const WX_API='https://api.open-meteo.com/v1/forecast?latitude=29.86&longitude=-98.26&current=temperature_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_gusts_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=America%2FChicago&forecast_days=7';
const CONSERVATION_POOL=909;
const WATER_CACHE_KEY='tg-gruene-water-snapshot-v1';
const BUNDLED_WATER={savedAt:'2026-09-28T00:50:00Z',el:908.03,delta:null,diff:-0.97,sattler:{flow:151,stage:null},city:{flow:194,stage:null},comal:{flow:159,stage:null},weather:{}};
function latest(series){const vals=series?.values?.[0]?.value||[];return vals.length?vals[vals.length-1]:null}
function first(series){const vals=series?.values?.[0]?.value||[];return vals.length?vals[0]:null}
function n(v){const x=parseFloat(v);return Number.isFinite(x)?x:null}
function findParam(data,code){return(data?.value?.timeSeries||[]).find(s=>(s.variable?.variableCode||[]).some(c=>c.value===code))}
function values(data){return{flow:n(latest(findParam(data,'00060'))?.value),stage:n(latest(findParam(data,'00065'))?.value)}}
function fmt(v,d=1){return v==null?'—':Number(v).toFixed(d)}
function weatherText(code){const m={0:'Clear',1:'Mostly clear',2:'Partly cloudy',3:'Cloudy',45:'Fog',48:'Fog',51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',71:'Light snow',80:'Showers',81:'Showers',82:'Heavy showers',95:'Thunderstorms',96:'Thunderstorms',99:'Severe thunderstorms'};return m[code]||'Current conditions'}
function trendText(delta){if(delta==null)return'Trend unavailable';if(Math.abs(delta)<.03)return'essentially steady over 48 hours';return delta>0?`up ${Math.abs(delta).toFixed(2)} ft over 48 hours`:`down ${Math.abs(delta).toFixed(2)} ft over 48 hours`}
function poolText(diff){if(diff==null)return'Comparison unavailable';if(Math.abs(diff)<.05)return'at the 909-ft conservation pool';return`${Math.abs(diff).toFixed(2)} ft ${diff>0?'above':'below'} the 909-ft conservation pool`}
function flowLabel(flow){if(flow==null)return'Live reading unavailable';if(flow<100)return'very low flow';if(flow<300)return'lower flow';if(flow<1000)return'moderate flow';return'elevated flow'}
function tonysRead({gust,precipProb,lakeDiff,lakeDelta,sattler,city,comal}){const lines=[];
 if(lakeDiff!=null){lines.push(`Canyon Lake is ${poolText(lakeDiff)}.`);if(lakeDiff<-.5)lines.push('That does not cancel a lake day, but confirm your chosen ramp and shoreline access before towing a boat or promising an easy swim entry.');else lines.push('Lake elevation alone does not confirm that every ramp or park is open.');}
 if(lakeDelta!=null&&Math.abs(lakeDelta)>=.08)lines.push(`The reservoir has been ${lakeDelta>0?'rising':'falling'} over the last 48 hours, so use today’s access report rather than an old photo or review.`);
 if(sattler!=null){if(sattler<100)lines.push(`At Sattler, ${Math.round(sattler)} cfs is very low; I would not build a Guadalupe float around it without speaking directly to an outfitter.`);else if(sattler<300)lines.push(`At Sattler, ${Math.round(sattler)} cfs means a slower, shallower Guadalupe float with more attention to exposed rock and the route an outfitter is actually running.`);else if(sattler<1000)lines.push(`At Sattler, ${Math.round(sattler)} cfs is a more useful recreational flow, but trip length, access and operator rules still decide the day.`);else lines.push(`At Sattler, ${Math.round(sattler)} cfs is elevated enough that I would check current outfitter operations and official warnings before entering.`);}
 if(city!=null&&sattler!=null&&Math.abs(city-sattler)>75)lines.push('The New Braunfels Guadalupe gauge is materially different, so do not use the Sattler number to judge every downstream reach.');
 if(comal!=null){if(comal<200)lines.push(`The Comal is at ${Math.round(comal)} cfs; expect a gentler current, but verify city access and tube-chute conditions.`);else lines.push(`The Comal is at ${Math.round(comal)} cfs; check city access and tube-chute conditions before choosing it over the Guadalupe.`);}
 if(gust!=null&&gust>=25)lines.push('Strong gusts make open-water boating and paddling the weak choice today.');if(precipProb!=null&&precipProb>=50)lines.push('Keep a dry alternative ready and recheck radar before entering the water.');
 lines.push('My call: choose the exact reach first, then confirm the ramp, park or outfitter—not just the regional gauge number.');return lines.join(' ')}
function setText(id,v){const e=document.getElementById(id);if(e)e.textContent=v}
function hasWater(s){return !!s&&(s.el!=null||s.sattler?.flow!=null||s.city?.flow!=null||s.comal?.flow!=null)}
function mergeWater(base,next){return{
 ...base,...next,
 el:next.el??base.el,delta:next.delta??base.delta,diff:next.diff??base.diff,
 sattler:{...(base.sattler||{}),...(next.sattler||{}),flow:next.sattler?.flow??base.sattler?.flow,stage:next.sattler?.stage??base.sattler?.stage},
 city:{...(base.city||{}),...(next.city||{}),flow:next.city?.flow??base.city?.flow,stage:next.city?.stage??base.city?.stage},
 comal:{...(base.comal||{}),...(next.comal||{}),flow:next.comal?.flow??base.comal?.flow,stage:next.comal?.stage??base.comal?.stage},
 weather:{...(base.weather||{}),...(next.weather||{})},precipProb:next.precipProb??base.precipProb
}}
function renderWater(s,label){
 const cur=s.weather||{},el=s.el,delta=s.delta,diff=s.diff,sattler=s.sattler||{},city=s.city||{},comal=s.comal||{};
 setText('wx-temp',cur.temperature_2m!=null?`${Math.round(cur.temperature_2m)}°F`:'—');setText('wx-desc',cur.weather_code!=null?weatherText(cur.weather_code):'Weather refreshing…');setText('wx-wind',cur.wind_speed_10m!=null?`${Math.round(cur.wind_speed_10m)} mph wind · gusts ${Math.round(cur.wind_gusts_10m||0)} mph`:'');
 setText('lake-elev',el!=null?`${fmt(el,2)} ft`:'—');setText('lake-trend',trendText(delta));setText('lake-pool',poolText(diff));
 setText('sattler-flow',sattler.flow!=null?`${Math.round(sattler.flow)} cfs`:'—');setText('sattler-stage',sattler.stage!=null?`${fmt(sattler.stage,2)} ft`:'—');setText('sattler-label',flowLabel(sattler.flow));
 setText('guad-flow',city.flow!=null?`${Math.round(city.flow)} cfs`:'—');setText('guad-stage',city.stage!=null?`${fmt(city.stage,2)} ft`:'—');setText('guad-label',flowLabel(city.flow));
 setText('comal-flow',comal.flow!=null?`${Math.round(comal.flow)} cfs`:'—');setText('comal-stage',comal.stage!=null?`${fmt(comal.stage,2)} ft`:'—');setText('comal-label',flowLabel(comal.flow));
 setText('tonys-read',tonysRead({gust:cur.wind_gusts_10m,precipProb:s.precipProb,lakeDiff:diff,lakeDelta:delta,sattler:sattler.flow,city:city.flow,comal:comal.flow}));setText('updated',label);
 const bar=document.getElementById('pool-bar');if(bar&&diff!=null)bar.style.width=`${Math.max(8,Math.min(92,50+diff*4))}%`;
}
function renderFastWater(){let s=BUNDLED_WATER,label='Recent verified snapshot · refreshing live gauges…';try{const c=JSON.parse(localStorage.getItem(WATER_CACHE_KEY)||'null');if(hasWater(c)&&c.savedAt&&Date.now()-new Date(c.savedAt).getTime()<36*3600000){s=mergeWater(BUNDLED_WATER,c);label=`Recent reading from ${new Date(c.savedAt).toLocaleString([],{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})} · refreshing…`}}catch(e){}renderWater(s,label);return s}
async function getJson(url){try{const r=await fetch(url);return r.ok?await r.json():null}catch(e){return null}}
async function loadNow(){
 const[lake,sattlerData,cityData,comalData,wx]=await Promise.all([LAKE_API,SATTLER_API,NEW_BRAUNFELS_API,COMAL_API,WX_API].map(getJson));
 const elev=findParam(lake,'62614'),wind=findParam(lake,'00035'),wdir=findParam(lake,'00036'),rain=findParam(lake,'00045');
 const el=n(latest(elev)?.value),oldEl=n(first(elev)?.value),delta=el!=null&&oldEl!=null?el-oldEl:null,diff=el!=null?el-CONSERVATION_POOL:null;
 const sattler=values(sattlerData),city=values(cityData),comal=values(comalData),windVal=n(latest(wind)?.value),dirVal=n(latest(wdir)?.value),precip=n(latest(rain)?.value),cur=wx?.current||{},daily=wx?.daily||{},precipProb=daily?.precipitation_probability_max?.[0]??null;
 if(el==null&&sattler.flow==null&&city.flow==null&&comal.flow==null&&cur.temperature_2m==null){setText('updated','Live sources are slow · showing the most recent verified reading');return}
 let prior=BUNDLED_WATER;try{const c=JSON.parse(localStorage.getItem(WATER_CACHE_KEY)||'null');if(hasWater(c))prior=mergeWater(prior,c)}catch(e){}
 const snapshot=mergeWater(prior,{el,delta,diff,sattler,city,comal,weather:cur,precipProb});
 renderWater(snapshot,'Refreshing observation time…');
 const set=setText;
 if(windVal!=null)set('lake-wind',`${fmt(windVal,1)} mph${dirVal!=null?` · ${Math.round(dirVal)}°`:''}`);if(precip!=null)set('lake-rain',`${fmt(precip,2)} in`);
 const stamp=[latest(elev)?.dateTime,latest(findParam(sattlerData,'00060'))?.dateTime,latest(findParam(comalData,'00060'))?.dateTime].filter(Boolean).sort().pop();set('updated',stamp?`Latest gauge observation ${new Date(stamp).toLocaleString([],{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}`:`Checked ${new Date().toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}; some gauges unavailable`);
 try{localStorage.setItem(WATER_CACHE_KEY,JSON.stringify({...snapshot,savedAt:stamp||new Date().toISOString()}))}catch(e){}
 document.querySelectorAll('.status-dot').forEach(d=>d.classList.toggle('live',!!(el!=null||sattler.flow!=null||comal.flow!=null)));const bar=document.getElementById('pool-bar');if(bar&&diff!=null)bar.style.width=`${Math.max(8,Math.min(92,50+diff*4))}%`;
 const forecast=document.getElementById('forecast');if(forecast&&daily.time)forecast.innerHTML=daily.time.map((day,i)=>`<div class="forecast-card"><strong>${new Intl.DateTimeFormat('en-US',{weekday:'short'}).format(new Date(day+'T12:00:00'))}</strong><div>${Math.round(daily.temperature_2m_max[i])}° / ${Math.round(daily.temperature_2m_min[i])}°</div><div class="note">${daily.precipitation_probability_max[i]??0}% rain</div></div>`).join('');
}
function startWater(){try{renderFastWater()}catch(e){setText('updated','Showing the most recent verified readings · checking live gauges…')}loadNow().catch(()=>setText('updated','Live sources are slow · showing the most recent verified readings'))}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startWater,{once:true});else startWater();
