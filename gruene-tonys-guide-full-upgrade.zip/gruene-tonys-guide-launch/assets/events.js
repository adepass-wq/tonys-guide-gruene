
const API='https://tonys-guide-gruene-events-live.onrender.com/events';
let ALL=[];
function d(x){return new Date(x)}
function fmtDay(x){return new Intl.DateTimeFormat('en-US',{weekday:'short',month:'short',day:'numeric'}).format(d(x))}
function fmtTime(x){return new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit'}).format(d(x))}
function esc(s){return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
const musicStyles={
  'Lee Mathis & The Brutally Handsome Band':'outlaw and traditional country, Western swing, blues and Southern rock',
  'Wade Forster':'contemporary country rooted in rodeo storytelling',
  'Ruben V':'Texas blues, roadhouse rock and Latin-influenced roots music',
  'Tony Taylor':'Texas country and acoustic singer-songwriter music',
  'Adam Johnson Band':'Texas blues and roots rock',
  'Jamie Richards':'traditional country and honky-tonk',
  'Kathy Mattea':'country, folk and Appalachian acoustic music',
  'Casey Donahew':'Texas country and Red Dirt',
  'Friday Afternoon Club':'Texas country and Americana song-swaps with a rotating lineup',
  'Gage Gardiner':'contemporary country singer-songwriter music',
  'Matthew Ryan Band':'traditional Texas country and dance-hall music',
  'Kathy Murray & The Killowatts':'Texas blues, roots rock and roadhouse R&B',
  'The Doobie Others':'Doobie Brothers tribute music and 1970s classic rock',
  'Home Free':'country-pop in all-vocal a cappella arrangements',
  'Josh Weathers':'soul, R&B, gospel-inflected rock and Texas roots music',
  'Gene Watson':'classic country and honky-tonk'
};
function eventSummary(e){
  if(e.description) return e.description;
  const kind=(e.category||'event').toLowerCase();
  if(kind.includes('music') && musicStyles[e.title]) return `${e.title} performs ${musicStyles[e.title]}; choose it when that sound fits the evening rather than treating every live-music listing as interchangeable.`;
  if(kind.includes('music')) return `${e.title} is a live performance; verify the artist’s genre and lineup with the official listing before deciding whether the show fits your evening.`;
  if(kind.includes('family')) return `A family-oriented event; confirm the age fit, weather plan, duration and any registration requirement before promising it to children.`;
  if(kind.includes('food')) return `A food-and-drink event best treated as the day’s anchor; compare ticket inclusions, age rules and transportation before committing.`;
  if(kind.includes('sport')) return `A spectator or participation event that requires advance planning for access, walking, timing and weather.`;
  return `A ${kind} event worth evaluating by program, audience, admission and travel time before adding it to the day.`;
}
function active(e){
  const end=e.end?d(e.end):d(e.start);
  return end.getTime() >= Date.now();
}
function todayKey(x){const q=d(x);return `${q.getFullYear()}-${q.getMonth()+1}-${q.getDate()}`}
function render(){
  const area=document.querySelector('#area')?.value||'All';
  const cat=document.querySelector('#cat')?.value||'All';
  const when=document.querySelector('#when')?.value||'All';
  const q=(document.querySelector('#eventq')?.value||'').toLowerCase().trim();
  const now=new Date(), week=new Date(now.getTime()+7*86400000), month=new Date(now.getTime()+31*86400000);
  let ev=ALL.filter(active).filter(e=>area==='All'||e.area===area).filter(e=>cat==='All'||e.category===cat);
  if(when==='Today') ev=ev.filter(e=>todayKey(e.start)===todayKey(now));
  if(when==='7 days') ev=ev.filter(e=>d(e.start)<=week);
  if(when==='30 days') ev=ev.filter(e=>d(e.start)<=month);
  if(q) ev=ev.filter(e=>`${e.title} ${e.venue} ${e.area} ${e.category} ${e.genre||''} ${eventSummary(e)}`.toLowerCase().includes(q));
  ev.sort((a,b)=>d(a.start)-d(b.start));
  document.querySelector('#count').textContent=`${ev.length} upcoming event${ev.length===1?'':'s'} shown`;
  const by={}; ev.forEach(e=>(by[fmtDay(e.start)]??=[]).push(e));
  const out=document.querySelector('#eventlist');
  if(!ev.length){out.innerHTML='<div class="event-empty">No matching upcoming events. Try widening the filters.</div>';return}
  out.innerHTML=Object.entries(by).map(([day,items])=>`<section class="event-day"><h2>${day}</h2>${items.map(e=>`
  <article class="event-card">
    <div><span class="event-cat">${esc(e.category)}</span><h3>${esc(e.title)}</h3>
    <p><strong>${fmtTime(e.start)}${e.end?' – '+fmtTime(e.end):''}</strong> · ${esc(e.venue||e.area)}</p>
    <p class="event-summary">${esc(eventSummary(e))}</p>
    <p class="note"><strong>Cost:</strong> ${esc(e.price_context||e.price||'Price not supplied — check the official listing')} · ${esc(e.area)}${e.source_name?' · '+esc(e.source_name):''}</p></div>
    <a class="btn event-btn" href="${esc(e.source)}" target="_blank" rel="noopener">Details</a>
  </article>`).join('')}</section>`).join('');
}
async function loadEvents(){
  let data=[];
  try{
    const r=await fetch(API,{cache:'no-store'});
    if(r.ok){const j=await r.json();data=j.events||[];document.querySelector('#live-status').textContent=`Live sources refreshed ${new Date(j.fetched_at).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}`;}
  }catch(e){}
  if(!data.length){
    const r=await fetch('/events-fallback.json',{cache:'no-store'}); data=await r.json();
    document.querySelector('#live-status').textContent='Showing verified fallback calendar while live sources refresh';
  }
  ALL=data.filter(active);
  [...new Set(ALL.map(e=>e.area).filter(Boolean))].sort().forEach(v=>area.insertAdjacentHTML('beforeend',`<option>${esc(v)}</option>`));
  [...new Set(ALL.map(e=>e.category).filter(Boolean))].sort().forEach(v=>cat.insertAdjacentHTML('beforeend',`<option>${esc(v)}</option>`));
  render();
}
document.addEventListener('DOMContentLoaded',()=>{
 ['area','cat','when','eventq'].forEach(id=>document.getElementById(id)?.addEventListener(id==='eventq'?'input':'change',render));
 loadEvents();
});
