const API='https://tonys-guide-gruene-events-live.onrender.com/events';
let ALL=[], QUICK='all', VIEW='day';
const SEARCH_ALIASES={acl:['austin city limits'],f1:['formula 1'],play:['theatre','theater','musical'],plays:['theatre','theater','musical'],stage:['theatre','performance'],kids:['family','children'],brew:['beer','brewers']};
const SAVED=new Set(JSON.parse(localStorage.getItem('tg-gruene-events')||'[]'));
function d(x){return new Date(x)}
function clean(s){const box=document.createElement('textarea');box.innerHTML=s||'';return box.value}
function esc(s){return clean(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function fmtDay(x){return new Intl.DateTimeFormat('en-US',{weekday:'short',month:'short',day:'numeric'}).format(d(x))}
function fmtMonth(x){return new Intl.DateTimeFormat('en-US',{month:'long',year:'numeric'}).format(d(x))}
function fmtTime(x){return new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit'}).format(d(x))}
function localDate(x){const z=d(x);return `${z.getFullYear()}-${String(z.getMonth()+1).padStart(2,'0')}-${String(z.getDate()).padStart(2,'0')}`}
function active(e){return d(e.end||e.start).getTime()>=Date.now()}
function eventId(e){return `${clean(e.title).toLowerCase()}|${e.start}|${clean(e.venue).toLowerCase()}`}
function endOfWeekend(){const n=new Date(),day=n.getDay(),add=day===0?0:7-day,end=new Date(n);end.setDate(n.getDate()+add);end.setHours(23,59,59,999);return end}
function selectedEvents(){
 const area=document.querySelector('#area')?.value||'All areas',cat=document.querySelector('#cat')?.value||'All genres';
 const q=(document.querySelector('#eventq')?.value||'').toLowerCase().trim(),from=document.querySelector('#date-from')?.value,to=document.querySelector('#date-to')?.value;
 const now=new Date(),seven=new Date(now.getTime()+7*86400000),thirty=new Date(now.getTime()+30*86400000);
 let ev=ALL.filter(active).filter(e=>area==='All areas'||e.area===area).filter(e=>cat==='All genres'||e.category===cat);
 if(q){const raw=q.split(/\s+/).filter(Boolean);ev=ev.filter(e=>{const hay=`${clean(e.title)} ${clean(e.venue)} ${e.area} ${e.category} ${e.source_name||''}`.toLowerCase();return raw.every(term=>hay.includes(term)||(SEARCH_ALIASES[term]||[]).some(alias=>hay.includes(alias)))})}
 if(from)ev=ev.filter(e=>localDate(e.start)>=from);if(to)ev=ev.filter(e=>localDate(e.start)<=to);
 if(QUICK==='today')ev=ev.filter(e=>localDate(e.start)===localDate(now));if(QUICK==='weekend')ev=ev.filter(e=>d(e.start)<=endOfWeekend());
 if(QUICK==='7')ev=ev.filter(e=>d(e.start)<=seven);if(QUICK==='30')ev=ev.filter(e=>d(e.start)<=thirty);if(QUICK==='saved')ev=ev.filter(e=>SAVED.has(eventId(e)));
 if(QUICK==='local')ev=ev.filter(e=>!['Austin','San Antonio'].includes(e.area));if(QUICK==='drive')ev=ev.filter(e=>['Austin','San Antonio'].includes(e.area));
 const sort=document.querySelector('#sort')?.value||'date';
 ev.sort((a,b)=>sort==='genre'?a.category.localeCompare(b.category)||d(a.start)-d(b.start):sort==='area'?a.area.localeCompare(b.area)||d(a.start)-d(b.start):d(a.start)-d(b.start));return ev;
}
function card(e){const id=eventId(e),saved=SAVED.has(id),same=e.end&&d(e.end).getTime()===d(e.start).getTime(),drive=['Austin','San Antonio'].includes(e.area),driveText=e.drive||({Austin:'About 50–65 minutes from Gruene','San Antonio':'About 40–55 minutes from Gruene'}[e.area]),time=e.all_day?'See official schedule':fmtTime(e.start)+(e.end&&!same?' – '+fmtTime(e.end):''),place=[clean(e.venue),e.area,'Texas'].filter(Boolean).join(', '),mapUrl='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(place);return `<article class="event-card ${drive?'destination-event':''}"><div>${drive?'<span class="drive-badge">WORTH THE DRIVE · '+esc(e.area)+'</span>':''}<span class="event-cat">${esc(e.category)}</span><h3>${esc(e.title)}</h3><p><strong>${time}</strong> · ${esc(e.venue||e.area)}</p><p class="note">${esc(e.area)}${e.price?' · '+esc(e.price):''}${e.source_name?' · '+esc(e.source_name):''}</p>${drive?`<p class="drive-note"><strong>Drive:</strong> ${esc(driveText)}<br><strong>Tony’s call:</strong> ${esc(e.tony||'Worth considering when this event is the anchor—not as an add-on to an already full Gruene day.')}</p>`:''}</div><div class="event-actions"><button class="event-save ${saved?'saved':''}" data-save="${encodeURIComponent(id)}" type="button">${saved?'Saved ✓':'Save event'}</button><a class="map-link" href="${mapUrl}" target="_blank" rel="noopener" aria-label="Open ${esc(place)} in Google Maps">Map & directions</a><a class="btn event-btn" href="${esc(e.source)}" target="_blank" rel="noopener">Official details</a></div></article>`}
function render(){const ev=selectedEvents(),out=document.querySelector('#eventlist'),local=ev.filter(e=>!['Austin','San Antonio'].includes(e.area)).length,drive=ev.length-local;document.querySelector('#count').textContent=`${ev.length} upcoming · ${local} local · ${drive} worth the drive · ${SAVED.size} saved`;if(!ev.length){out.innerHTML='<div class="event-empty">No matching upcoming events. Clear a date or widen the filters.</div>';return}const by={};ev.forEach(e=>{const k=VIEW==='month'?fmtMonth(e.start):fmtDay(e.start);(by[k]??=[]).push(e)});out.innerHTML=Object.entries(by).map(([label,items])=>`<section class="${VIEW==='month'?'event-month':'event-day'}"><h2>${label}</h2>${items.map(card).join('')}</section>`).join('')}
function resetQuick(value){QUICK=value;document.querySelectorAll('[data-quick]').forEach(b=>b.classList.toggle('active',b.dataset.quick===value));render()}
async function loadEvents(){
 let live=[];try{const controller=new AbortController();setTimeout(()=>controller.abort(),3500);const r=await fetch(API,{cache:'no-store',signal:controller.signal});if(r.ok){const j=await r.json();live=j.events||[];document.querySelector('#live-status').textContent=`Live sources refreshed ${new Date(j.fetched_at).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}`}}catch(e){}
 let verified=[];try{const r=await fetch('/events-fallback.json',{cache:'no-store'});if(r.ok)verified=await r.json()}catch(e){}
 let destination=[];try{const r=await fetch('/events-destination.json',{cache:'no-store'});if(r.ok)destination=await r.json()}catch(e){}
 if(!live.length)document.querySelector('#live-status').textContent='Showing the verified calendar while live sources refresh';
 const merged=new Map();[...verified,...destination,...live].forEach(e=>{merged.set(`${clean(e.title).toLowerCase()}|${localDate(e.start)}|${clean(e.venue).toLowerCase()}`,e)});ALL=[...merged.values()].filter(active);
 [...new Set(ALL.map(e=>e.area).filter(Boolean))].sort().forEach(v=>document.querySelector('#area')?.insertAdjacentHTML('beforeend',`<option>${esc(v)}</option>`));
 [...new Set(ALL.map(e=>e.category).filter(Boolean))].sort().forEach(v=>document.querySelector('#cat')?.insertAdjacentHTML('beforeend',`<option>${esc(v)}</option>`));render();
}
document.addEventListener('DOMContentLoaded',()=>{
 const initialSearch=new URLSearchParams(location.search).get('search');if(initialSearch&&document.getElementById('eventq'))document.getElementById('eventq').value=initialSearch;
 ['area','cat','sort','date-from','date-to','eventq'].forEach(id=>document.getElementById(id)?.addEventListener(id==='eventq'?'input':'change',()=>{if(id==='date-from'||id==='date-to')resetQuick('all');else render()}));
 document.querySelector('.quick-filters')?.addEventListener('click',e=>{const b=e.target.closest('[data-quick]');if(b)resetQuick(b.dataset.quick)});
 document.querySelector('.event-lanes')?.addEventListener('click',e=>{const b=e.target.closest('[data-lane]');if(!b)return;const select=document.querySelector('#cat');if(select&&[...select.options].some(o=>o.value===b.dataset.lane)){select.value=b.dataset.lane;resetQuick('all');document.querySelector('#eventlist')?.scrollIntoView({behavior:'smooth',block:'start'})}});
 document.querySelector('.view-toggle')?.addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(!b)return;VIEW=b.dataset.view;document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x===b));render()});
 document.querySelector('#eventlist')?.addEventListener('click',e=>{const b=e.target.closest('[data-save]');if(!b)return;const id=decodeURIComponent(b.dataset.save);SAVED.has(id)?SAVED.delete(id):SAVED.add(id);localStorage.setItem('tg-gruene-events',JSON.stringify([...SAVED]));render()});loadEvents();
});
