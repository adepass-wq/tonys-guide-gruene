const API='https://tonys-guide-gruene-events-live.onrender.com/events';
let ALL=[];
function d(x){return new Date(x)}
function fmtDay(x){return new Intl.DateTimeFormat('en-US',{weekday:'short',month:'short',day:'numeric'}).format(d(x))}
function fmtTime(x){return new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit'}).format(d(x))}
function esc(s){return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function clean(s){const box=document.createElement('textarea');box.innerHTML=s||'';return box.value}
function active(e){
  const end=e.end?d(e.end):d(e.start);
  return end.getTime() >= Date.now();
}
function todayKey(x){const q=d(x);return `${q.getFullYear()}-${q.getMonth()+1}-${q.getDate()}`}
function render(){
  const areaSelect=document.querySelector('#area');
  const categorySelect=document.querySelector('#cat');
  const whenSelect=document.querySelector('#when');
  const area=areaSelect?.value||'All';
  const cat=categorySelect?.value||'All';
  const when=whenSelect?.value||'All';
  const q=(document.querySelector('#eventq')?.value||'').toLowerCase().trim();
  const now=new Date(), week=new Date(now.getTime()+7*86400000), month=new Date(now.getTime()+31*86400000);
  let ev=ALL.filter(active).filter(e=>area==='All'||e.area===area).filter(e=>cat==='All'||e.category===cat);
  if(when==='Today') ev=ev.filter(e=>todayKey(e.start)===todayKey(now));
  if(when==='7 days') ev=ev.filter(e=>d(e.start)<=week);
  if(when==='30 days') ev=ev.filter(e=>d(e.start)<=month);
  if(q) ev=ev.filter(e=>`${e.title} ${e.venue} ${e.area} ${e.category}`.toLowerCase().includes(q));
  ev.sort((a,b)=>d(a.start)-d(b.start));
  document.querySelector('#count').textContent=`${ev.length} upcoming event${ev.length===1?'':'s'} shown`;
  const by={}; ev.forEach(e=>(by[fmtDay(e.start)]??=[]).push(e));
  const out=document.querySelector('#eventlist');
  if(!ev.length){out.innerHTML='<div class="event-empty">No matching upcoming events. Try widening the filters.</div>';return}
  out.innerHTML=Object.entries(by).map(([day,items])=>`<section class="event-day"><h2>${day}</h2>${items.map(e=>`
  <article class="event-card">
    <div><span class="event-cat">${esc(clean(e.category))}</span><h3>${esc(clean(e.title))}</h3>
    <p><strong>${fmtTime(e.start)}${e.end&&d(e.end).getTime()!==d(e.start).getTime()?' – '+fmtTime(e.end):''}</strong> · ${esc(clean(e.venue||e.area))}</p>
    <p class="note">${esc(clean(e.area))}${e.price?' · '+esc(clean(e.price)):''}${e.source_name?' · '+esc(clean(e.source_name)):''}</p></div>
    <a class="btn event-btn" href="${esc(e.source)}" target="_blank" rel="noopener">Details</a>
  </article>`).join('')}</section>`).join('');
}
async function loadEvents(){
  let live=[];
  try{
    const r=await fetch(API,{cache:'no-store'});
    if(r.ok){const j=await r.json();live=j.events||[];document.querySelector('#live-status').textContent=`Live sources refreshed ${new Date(j.fetched_at).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}`;}
  }catch(e){}
  let verified=[];
  try{const r=await fetch('/events-fallback.json',{cache:'no-store'});if(r.ok)verified=await r.json();}catch(e){}
  if(!live.length){
    document.querySelector('#live-status').textContent='Showing verified fallback calendar while live sources refresh';
  }
  const merged=new Map();
  [...verified,...live].forEach(e=>merged.set(`${clean(e.title).toLowerCase()}|${e.start}`,e));
  ALL=[...merged.values()].filter(active);
  const areaSelect=document.querySelector('#area');
  const categorySelect=document.querySelector('#cat');
  [...new Set(ALL.map(e=>e.area).filter(Boolean))].sort().forEach(v=>areaSelect?.insertAdjacentHTML('beforeend',`<option>${esc(v)}</option>`));
  [...new Set(ALL.map(e=>e.category).filter(Boolean))].sort().forEach(v=>categorySelect?.insertAdjacentHTML('beforeend',`<option>${esc(v)}</option>`));
  render();
}
document.addEventListener('DOMContentLoaded',()=>{
  ['area','cat','when','eventq'].forEach(id=>document.getElementById(id)?.addEventListener(id==='eventq'?'input':'change',render));
  loadEvents();
});
