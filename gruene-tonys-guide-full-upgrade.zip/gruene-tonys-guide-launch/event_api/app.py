
from flask import Flask, jsonify
from flask_cors import CORS
import requests, json, re, time
from bs4 import BeautifulSoup
from datetime import datetime, timezone
from dateutil import parser as dateparser

app=Flask(__name__); CORS(app)
CACHE={"at":0,"events":[]}
SOURCES=[
 ("Gruene","https://www.gruenetexas.com/events/","Gruene"),
 ("Gruene Hall","https://gruenehall.com/calendar/","Gruene"),
 ("Gristmill","https://gristmillrestaurant.com/events/","Gruene"),
 ("Krause's Cafe","https://krausescafe.com/events/","New Braunfels"),
 ("City of New Braunfels","https://newbraunfels.gov/specialevents","New Braunfels"),
 ("New Braunfels Community","https://newbraunfelschamber.growthzoneapp.com/communitycalendar","New Braunfels"),
 ("Canyon Lake Chamber","https://business.canyonlakechamber.com/event-calendar","Canyon Lake"),
 ("Brauntex Theatre","https://brauntex.org/events/","New Braunfels"),
 ("Visit Austin Major Events","https://www.austintexas.org/events/october-and-november/","Austin"),
 ("Texas Performing Arts","https://texasperformingarts.org/events","Austin"),
 ("ZACH Theatre","https://tickets.zachtheatre.org/events","Austin"),
 ("Tobin Center","https://www.tobincenter.org/events","San Antonio"),
 ("San Pedro Playhouse","https://www.sanpedroplayhouse.org/shows","San Antonio"),
 ("San Antonio River Walk","https://www.thesanantonioriverwalk.com/events/","San Antonio"),
]
def cat(title,venue=""):
 t=(title+" "+venue).lower()
 if any(x in t for x in ["theatre","theater","musical","ballet","opera","play","comedy","broadway"]): return "Theatre & Performance"
 if any(x in t for x in ["music","band","concert","hall","duo","singer","dance"]): return "Live Music"
 if any(x in t for x in ["food","wine","chef","culinary","beer","bbq"]): return "Food & Drink"
 if any(x in t for x in ["market","festival","fair","wurstfest"]): return "Market & Festival"
 if any(x in t for x in ["kid","family","pumpkin","movie","flick","spook"]): return "Family"
 if any(x in t for x in ["art","clay","museum","historic","heritage"]): return "Arts & Culture"
 if any(x in t for x in ["run","race","golf","5k","10k"]): return "Sports & Outdoors"
 return "Community"
def iso(v):
 try:return dateparser.parse(v).isoformat()
 except:return None
def jsonld_events(soup,source_name,source_url,area):
 out=[]
 for tag in soup.find_all("script",type="application/ld+json"):
  try:
   obj=json.loads(tag.string or "")
   queue=obj if isinstance(obj,list) else [obj]
   for x in queue:
    if isinstance(x,dict) and x.get("@type")=="Event":
     loc=x.get("location",{}); venue=loc.get("name","") if isinstance(loc,dict) else ""
     st=iso(x.get("startDate","")); en=iso(x.get("endDate","")) or st
     if st: out.append({"title":x.get("name","Event"),"start":st,"end":en,"venue":venue,"area":area,"category":cat(x.get("name",""),venue),"price":"","source":x.get("url") or source_url,"source_name":source_name})
  except: pass
 return out
def tribe_events(soup,source_name,source_url,area):
 out=[]
 selectors=[".tribe-events-calendar-list__event-row","article.type-tribe_events",".tribe-events-calendar-month__calendar-event"]
 for node in soup.select(",".join(selectors)):
  title_node=node.select_one("h3 a,h2 a,.tribe-events-calendar-list__event-title a")
  time_node=node.find("time",attrs={"datetime":True})
  if not title_node or not time_node: continue
  st=iso(time_node.get("datetime")); 
  if not st: continue
  venue_node=node.select_one(".tribe-events-calendar-list__event-venue-title,.tribe-venue")
  venue=venue_node.get_text(" ",strip=True) if venue_node else ""
  price_node=node.select_one(".tribe-events-c-small-cta__price,.tribe-events-event-cost")
  price=price_node.get_text(" ",strip=True) if price_node else ""
  out.append({"title":title_node.get_text(" ",strip=True),"start":st,"end":st,"venue":venue,"area":area,"category":cat(title_node.get_text(" ",strip=True),venue),"price":price,"source":title_node.get("href") or source_url,"source_name":source_name})
 return out
def fetch():
 ev=[]; headers={"User-Agent":"Mozilla/5.0 TonyGuideEvents/1.0"}
 for name,url,area in SOURCES:
  try:
   r=requests.get(url,headers=headers,timeout=15); r.raise_for_status()
   soup=BeautifulSoup(r.text,"html.parser")
   found=jsonld_events(soup,name,url,area)
   if not found: found=tribe_events(soup,name,url,area)
   ev.extend(found)
  except Exception: pass
 # dedupe and expire
 ded={}; now=datetime.now(timezone.utc)
 for e in ev:
  try:
   end=dateparser.parse(e.get("end") or e["start"])
   if end.tzinfo is None: end=end.replace(tzinfo=timezone.utc)
   if end < now: continue
  except: continue
  key=(e["title"].lower().strip(), e["start"][:10], e.get("venue","").lower().strip())
  ded[key]=e
 return sorted(ded.values(),key=lambda x:x["start"])
@app.get("/events")
def events():
 if time.time()-CACHE["at"]>1800 or not CACHE["events"]:
  data=fetch()
  if data: CACHE.update(at=time.time(),events=data)
 return jsonify({"fetched_at":datetime.now(timezone.utc).isoformat(),"events":CACHE["events"],"sources":[s[0] for s in SOURCES]})
@app.get("/health")
def health(): return {"ok":True}
