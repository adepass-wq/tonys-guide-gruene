
from flask import Flask, jsonify
from flask_cors import CORS
import requests, json, re, time
from bs4 import BeautifulSoup
from datetime import datetime, timezone
from dateutil import parser as dateparser
from urllib.parse import urljoin

app=Flask(__name__); CORS(app)
CACHE={"at":0,"events":[]}
SOURCES=[
 ("Gruene","https://www.gruenetexas.com/events/","Gruene"),
 ("Gruene Hall","https://gruenehall.com/calendar/","Gruene"),
 ("Gristmill","https://gristmillrestaurant.com/events/","Gruene"),
 ("Krause's Cafe","https://krausescafe.com/events/","New Braunfels"),
 ("City of New Braunfels","https://newbraunfels.gov/specialevents","New Braunfels"),
 ("New Braunfels Community","https://newbraunfelschamber.growthzoneapp.com/communitycalendar","New Braunfels"),
 ("Canyon Lake Chamber","https://business.canyonlakechamber.com/event-calendar","Canyon Lake"),
 ("Brauntex Theatre","https://brauntex.org/events/","New Braunfels"),
 ("Visit Austin Major Events","https://www.austintexas.org/events/october-and-november/","Austin"),
 ("Texas Performing Arts","https://texasperformingarts.org/events","Austin"),
 ("ZACH Theatre","https://tickets.zachtheatre.org/events","Austin"),
 ("Tobin Center","https://www.tobincenter.org/events","San Antonio"),
 ("San Pedro Playhouse","https://www.sanpedroplayhouse.org/shows","San Antonio"),
 ("San Antonio River Walk","https://www.thesanantonioriverwalk.com/events/","San Antonio"),
]
def cat(title,venue=""):
 t=(title+" "+venue).lower()
 if "financial literacy" in t:return "Community"
 music_names=["high kings","kathy mattea","doobie others","home free","josh weathers","gene watson","here come the mummies","choir! choir! choir!","mariachi","grand ol’ christmas","grand ol' christmas","under the streetlamp","texas cellos","gary p nunn","everly brothers","liverpool legends","bellamy brothers","motown","equinox orchestra","spin doctors","bee gees","walter trout","brandy clark","donny edwards","fab four","american revival","lisa morales","tom rush","chamber connexions"]
 if any(x in t for x in music_names):return "Live Music"
 if any(x in t for x in ["theatre","theater","musical","ballet","opera","play","comedy","broadway"]): return "Theatre & Performance"
 if any(x in t for x in ["music","band","concert","hall","duo","singer","dance"]): return "Live Music"
 if any(x in t for x in ["food","wine","chef","culinary","beer","bbq"]): return "Food & Drink"
 if any(x in t for x in ["market","festival","fair","wurstfest"]): return "Market & Festival"
 if any(x in t for x in ["kid","family","pumpkin","movie","flick","spook"]): return "Family"
 if any(x in t for x in ["art","clay","museum","historic","heritage"]): return "Arts & Culture"
 if any(x in t for x in ["run","race","golf","5k","10k"]): return "Sports & Outdoors"
 return "Community"
GENRES={
 "ruben v":"Texas blues, roadhouse rock and Latin-influenced roots",
 "tony taylor":"Texas country and acoustic singer-songwriter",
 "adam johnson band":"Texas blues and roots rock",
 "pivo & polka band":"polka and German-Texan dance music",
 "jamie richards":"traditional country and honky-tonk",
 "friday afternoon club":"Texas country and Americana song-swap",
 "landry scott ritter duo":"Texas country and acoustic Americana",
 "casey donahew":"Texas country and Red Dirt",
 "gage gardiner":"contemporary country singer-songwriter",
 "matthew ryan band":"traditional Texas country and dance-hall",
 "trevor underwood band":"Texas country and roots",
 "san antonio transit (chicago tribute band)":"Chicago tribute music, horn-driven classic rock and pop",
 "comal community band":"concert-band standards, marches and popular arrangements",
 "alli mattice duo":"acoustic country and pop",
 "trey gonzalez band":"Texas country and roots rock",
 "bill ayers band":"classic country and dance-hall music",
 "soul twang band":"country-soul, rhythm and blues and Texas roots",
 "a tribute to the music & memories of tony bennett starring steve leeds":"traditional pop, jazz standards and Tony Bennett tribute music",
}
def unescape(v):
 return BeautifulSoup(v or "","html.parser").get_text(" ",strip=True)
def genre_for(title):
 t=unescape(title).lower().strip()
 if t in GENRES:return GENRES[t]
 if "polka" in t:return "polka and German-Texan dance music"
 if "fab four" in t or "liverpool legends" in t:return "Beatles tribute music and 1960s pop-rock"
 if "high kings" in t:return "Irish folk and Celtic roots music"
 if "kathy mattea" in t:return "country, folk and Appalachian acoustic music"
 if "doobie" in t:return "Doobie Brothers tribute music and 1970s classic rock"
 if "home free" in t:return "country-pop in all-vocal a cappella arrangements"
 if "josh weathers" in t:return "soul, R&B, gospel-inflected rock and Texas roots"
 if "gene watson" in t:return "classic country and honky-tonk"
 if "mariachi" in t:return "mariachi and Mexican holiday music"
 if "cellos" in t or "chamber connexions" in t:return "classical and chamber music"
 if "motown" in t:return "Motown, soul and R&B"
 if "spin doctors" in t:return "alternative rock, blues-rock and 1990s pop-rock"
 if "walter trout" in t:return "electric blues and blues-rock"
 if "brandy clark" in t:return "country and Americana singer-songwriter music"
 if "gary p nunn" in t or "bellamy brothers" in t:return "classic country and Texas country"
 if "tom rush" in t:return "folk and acoustic singer-songwriter music"
 if "here come the mummies" in t:return "funk, soul and theatrical party music"
 if "choir! choir! choir!" in t:return "audience-participation pop and rock sing-along"
 if "grand ol" in t:return "country, western swing and holiday variety music"
 if "streetlamp" in t:return "vocal pop, doo-wop and holiday standards"
 if "equinox orchestra" in t:return "big-band jazz, swing and traditional pop"
 if "american revival" in t:return "Americana, country and roots music"
 if "lisa morales" in t:return "Americana, roots rock and Latin-influenced singer-songwriter music"
 if "gary p nunn" in t:return "Texas country and progressive country"
 if "tribute" in t and "beatles" in t:return "Beatles tribute music and 1960s pop-rock"
 if "tribute" in t:return "tribute music; verify the featured artist and repertoire"
 if "jazz" in t or "sinatra" in t:return "jazz and traditional pop standards"
 if "orchestra" in t or "symphony" in t:return "orchestral and classical music"
 if "band" in t:return "live band performance; verify the artist's style on the official page"
 return "live music; verify the artist's specific style on the official page"
def explain(e):
 title=unescape(e.get("title","Event")); area=e.get("area",""); venue=e.get("venue") or area
 category=e.get("category","Community")
 if category=="Live Music": return f"{title} is a performance of {genre_for(title)} at {venue}; choose it when that sound, setting and start time fit the evening."
 if category=="Theatre & Performance": return f"{title} is a staged performance at {venue}; check runtime, age guidance, seating and ticket terms before making it the evening's anchor."
 if category=="Food & Drink": return f"{title} is a food-and-drink event in {area}; compare admission inclusions, age rules and transportation before building the day around it."
 if category=="Market & Festival": return f"{title} is a market or festival in {area}; check the program, parking, weather plan and busiest hours before choosing how much of the day to commit."
 if category=="Family": return f"{title} is a family-oriented event in {area}; confirm the age fit, duration, registration and weather plan before promising it to children."
 if category=="Sports & Outdoors": return f"{title} is an outdoor or sporting event in {area}; check participation or spectator access, walking demands, weather and registration."
 if category=="Arts & Culture": return f"{title} is an arts or cultural program at {venue}; review the format and schedule to decide whether it merits a focused visit or a shorter stop."
 return f"{title} is a community event at {venue}; verify the program, intended audience, registration and time commitment before adding it to the day."
def enrich(e):
 e["title"]=unescape(e.get("title","Event")); e["venue"]=unescape(e.get("venue","")); e["price"]=unescape(e.get("price",""))
 e["genre"]=genre_for(e["title"]) if e.get("category")=="Live Music" else ""
 e["description"]=explain(e)
 e["price_context"]=e["price"] if e["price"] else "Price not supplied — check the official listing"
 return e
def quality_complete(e):
 required=bool(e.get("title") and e.get("start") and e.get("source") and e.get("description") and e.get("price_context"))
 music_ok=e.get("category")!="Live Music" or bool(e.get("genre"))
 return required and music_ok
def quality_report(events):
 music=[e for e in events if e.get("category")=="Live Music"]
 return {
  "active_events":len(events),
  "with_description":sum(bool(e.get("description")) for e in events),
  "with_price_context":sum(bool(e.get("price_context")) for e in events),
  "music_events":len(music),
  "music_with_genre":sum(bool(e.get("genre")) for e in music),
  "quality_complete":sum(quality_complete(e) for e in events),
  "standard":"Every event requires a decision-helpful description, cost status and official source; every music event also requires genre context."
 }
def iso(v):
 try:return dateparser.parse(v).isoformat()
 except:return None
def jsonld_events(soup,source_name,source_url,area):
 out=[]
 for tag in soup.find_all("script",type="application/ld+json"):
  try:
   obj=json.loads(tag.string or "")
   queue=obj if isinstance(obj,list) else [obj]
   for x in queue:
    if isinstance(x,dict) and x.get("@type")=="Event":
     loc=x.get("location",{}); venue=loc.get("name","") if isinstance(loc,dict) else ""
     st=iso(x.get("startDate","")); en=iso(x.get("endDate","")) or st
     if st: out.append({"title":x.get("name","Event"),"start":st,"end":en,"venue":venue,"area":area,"category":cat(x.get("name",""),venue),"price":"","source":x.get("url") or source_url,"source_name":source_name})
  except: pass
 return out
def tribe_events(soup,source_name,source_url,area):
 out=[]
 selectors=[".tribe-events-calendar-list__event-row","article.type-tribe_events",".tribe-events-calendar-month__calendar-event"]
 for node in soup.select(",".join(selectors)):
  title_node=node.select_one("h3 a,h2 a,.tribe-events-calendar-list__event-title a")
  time_node=node.find("time",attrs={"datetime":True})
  if not title_node or not time_node: continue
  st=iso(time_node.get("datetime")); 
  if not st: continue
  venue_node=node.select_one(".tribe-events-calendar-list__event-venue-title,.tribe-venue")
  venue=venue_node.get_text(" ",strip=True) if venue_node else ""
  price_node=node.select_one(".tribe-events-c-small-cta__price,.tribe-events-event-cost")
  price=price_node.get_text(" ",strip=True) if price_node else ""
  out.append({"title":title_node.get_text(" ",strip=True),"start":st,"end":st,"venue":venue,"area":area,"category":cat(title_node.get_text(" ",strip=True),venue),"price":price,"source":title_node.get("href") or source_url,"source_name":source_name})
 return out
def microdata_events(soup,source_name,source_url,area):
 out=[]
 for node in soup.select('[itemscope][itemtype*="Event"],.gz-event-card'):
  title_node=node.select_one('[itemprop="name"] a,[itemprop="name"],.gz-event-card-title')
  start_node=node.select_one('[itemprop="startDate"]')
  if not title_node or not start_node:continue
  st=iso(start_node.get('content') or start_node.get('datetime') or start_node.get_text(' ',strip=True))
  if not st:continue
  end_node=node.select_one('[itemprop="endDate"]'); en=iso((end_node.get('content') or end_node.get('datetime') or end_node.get_text(' ',strip=True)) if end_node else '') or st
  venue_node=node.select_one('[itemprop="location"],[itemprop="location"] [itemprop="name"],.gz-event-card-location')
  price_node=node.select_one('[itemprop="price"],.gz-event-card-price,.event-cost')
  href=title_node.get('href') if title_node.name=='a' else (title_node.find('a').get('href') if title_node.find('a') else source_url)
  title=title_node.get_text(' ',strip=True); venue=venue_node.get_text(' ',strip=True) if venue_node else ''
  out.append({'title':title,'start':st,'end':en,'venue':venue,'area':area,'category':cat(title,venue),'price':price_node.get_text(' ',strip=True) if price_node else '','source':urljoin(source_url,href),'source_name':source_name})
 return out
def tobin_events(soup,source_name,source_url,area):
 out=[]
 for node in soup.select('.views-row'):
  a=node.select_one('.views-field-title a'); date_node=node.select_one('.views-field-nothing')
  if not a or not date_node:continue
  txt=date_node.get_text(' ',strip=True)
  m=re.search(r'(?:on\s+)?([A-Z][a-z]{2}\s+\d{1,2},\s+20\d{2})',txt)
  if not m:continue
  st=iso(m.group(1)); title=a.get_text(' ',strip=True)
  out.append({'title':title,'start':st,'end':st,'venue':'Tobin Center','area':area,'category':cat(title,'Tobin Center'),'price':'','source':urljoin(source_url,a.get('href')),'source_name':source_name})
 return out
def fetch():
 ev=[]; headers={"User-Agent":"Mozilla/5.0 TonyGuideEvents/1.0"}
 for name,url,area in SOURCES:
  try:
   r=requests.get(url,headers=headers,timeout=15); r.raise_for_status()
   soup=BeautifulSoup(r.text,"html.parser")
   found=jsonld_events(soup,name,url,area)
   if not found: found=tribe_events(soup,name,url,area)
   if not found: found=microdata_events(soup,name,url,area)
   if not found and name=="Tobin Center": found=tobin_events(soup,name,url,area)
   ev.extend(found)
  except Exception: pass
 # dedupe and expire
 ded={}; now=datetime.now(timezone.utc)
 for e in ev:
  try:
   end=dateparser.parse(e.get("end") or e["start"])
   if end.tzinfo is None: end=end.replace(tzinfo=timezone.utc)
   if end < now: continue
  except: continue
  key=(e["title"].lower().strip(), e["start"][:10], e.get("venue","").lower().strip())
  ded[key]=enrich(e)
 return sorted((e for e in ded.values() if quality_complete(e)),key=lambda x:x["start"])
@app.get("/events")
def events():
 if time.time()-CACHE["at"]>1800 or not CACHE["events"]:
  data=fetch()
  if data: CACHE.update(at=time.time(),events=data)
 return jsonify({"fetched_at":datetime.now(timezone.utc).isoformat(),"events":CACHE["events"],"quality":quality_report(CACHE["events"]),"sources":[s[0] for s in SOURCES]})
@app.get("/health")
def health():
 report=quality_report(CACHE["events"])
 return {"ok":report["quality_complete"]==report["active_events"],"quality":report}
